"""Tests for ptytest package."""
